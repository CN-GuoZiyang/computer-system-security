#!/bin/sh

echo "请在源文件所在目录执行此脚本"
echo "获取root密码"
sudo echo "获取成功"

sudo rm *.exe
sudo rm *.o

echo "清除可执行文件完成"