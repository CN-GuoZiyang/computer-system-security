#!/bin/bash

echo "请在源文件所在目录执行此脚本"
echo "获取root密码"
sudo echo "获取成功"

sudo rm ./passwd
sudo chmod 666 ./aaa

sudo rm ./capset
sudo rm ./tryChangeTime